/* PUCKWERK Theme – kein Framework, keine Abhängigkeiten. Schlicht: nur Funktion, keine Dekor-Animation. */
(function () {
  'use strict';
  document.documentElement.classList.remove('no-js');

  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Menü (Handy): Panel von rechts ---------- */
  function initMenu() {
    var toggles = document.querySelectorAll('[data-menu-toggle]');
    var menu = document.querySelector('[data-menu]');
    var backdrop = document.querySelector('[data-menu-backdrop]');
    if (!toggles.length || !menu) return;
    function set(open) {
      toggles.forEach(function (t) { t.setAttribute('aria-expanded', String(open)); });
      document.body.classList.toggle('menu-open', open);
      if (open) {
        menu.hidden = false;
        if (backdrop) backdrop.hidden = false;
        requestAnimationFrame(function () {
          menu.classList.add('is-open');
          if (backdrop) backdrop.classList.add('is-open');
        });
      } else {
        menu.classList.remove('is-open');
        if (backdrop) backdrop.classList.remove('is-open');
        setTimeout(function () {
          if (!menu.classList.contains('is-open')) { menu.hidden = true; if (backdrop) backdrop.hidden = true; }
        }, reduceMotion ? 0 : 260);
      }
    }
    toggles.forEach(function (btn) { btn.addEventListener('click', function () { set(btn.getAttribute('aria-expanded') !== 'true'); }); });
    if (backdrop) backdrop.addEventListener('click', function () { set(false); });
    menu.addEventListener('click', function (e) { if (e.target.closest('a')) set(false); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && toggles[0].getAttribute('aria-expanded') === 'true') { set(false); toggles[0].focus(); }
    });
  }

  /* ---------- Suche: Feld unter der Kopfzeile ---------- */
  function initSearch() {
    var panel = document.querySelector('[data-search]');
    if (!panel) return;
    var toggles = document.querySelectorAll('[data-search-toggle]');
    function set(open) {
      panel.hidden = !open;
      toggles.forEach(function (t) { t.setAttribute('aria-expanded', String(open)); });
      if (open) { var input = panel.querySelector('input[type="search"]'); if (input) input.focus(); }
    }
    toggles.forEach(function (btn) { btn.addEventListener('click', function () { set(panel.hidden); }); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !panel.hidden) set(false); });
  }

  /* ---------- Ankündigungsleiste: Nachrichten im Wechsel ---------- */
  function initAnnouncement() {
    var track = document.querySelector('[data-announcement]');
    if (!track || track.dataset.ready) return;
    track.dataset.ready = '1';
    var items = track.querySelectorAll('.announcement__item');
    if (items.length < 2) return;
    var i = 0;
    setInterval(function () {
      items[i].classList.remove('is-active');
      i = (i + 1) % items.length;
      items[i].classList.add('is-active');
    }, 4500);
  }

  /* ---------- Mengen-Buttons ---------- */
  function initQty() {
    document.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-qty]');
      if (!btn) return;
      var input = btn.parentElement.querySelector('input[type="number"]');
      if (!input) return;
      var min = parseInt(input.min || '0', 10);
      var val = (parseInt(input.value, 10) || 0) + parseInt(btn.getAttribute('data-qty'), 10);
      input.value = Math.max(min, val);
      input.dispatchEvent(new Event('change', { bubbles: true }));
    });
  }

  /* ---------- Warenkorb: Mengen automatisch übernehmen ---------- */
  function initCartAutoUpdate() {
    var form = document.querySelector('[data-cart-form]');
    if (!form) return;
    var timer;
    form.addEventListener('change', function (e) {
      if (!e.target.matches('[data-cart-qty]')) return;
      clearTimeout(timer);
      timer = setTimeout(function () { form.submit(); }, 700);
    });
  }

  /* ---------- Sortierung ---------- */
  function initSort() {
    var select = document.querySelector('[data-sort]');
    if (!select) return;
    select.addEventListener('change', function () {
      var url = new URL(window.location.href);
      url.searchParams.set('sort_by', select.value);
      url.searchParams.delete('page');
      window.location.href = url.toString();
    });
  }

  /* ---------- Geldformat ---------- */
  function formatMoney(cents, format) {
    if (typeof cents === 'string') cents = cents.replace('.', '');
    format = format || '€{{amount_with_comma_separator}}';
    function fmt(number, precision, thousands, decimal) {
      thousands = typeof thousands === 'undefined' ? ',' : thousands;
      decimal = typeof decimal === 'undefined' ? '.' : decimal;
      if (isNaN(number) || number == null) return '0';
      number = (number / 100.0).toFixed(precision);
      var parts = number.split('.');
      var dollars = parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1' + thousands);
      var c = parts[1] ? decimal + parts[1] : '';
      return dollars + c;
    }
    return format.replace(/\{\{\s*(\w+)\s*\}\}/, function (_, key) {
      switch (key) {
        case 'amount': return fmt(cents, 2);
        case 'amount_no_decimals': return fmt(cents, 0);
        case 'amount_with_comma_separator': return fmt(cents, 2, '.', ',');
        case 'amount_no_decimals_with_comma_separator': return fmt(cents, 0, '.', ',');
        case 'amount_with_apostrophe_separator': return fmt(cents, 2, "'", '.');
        case 'amount_with_space_separator': return fmt(cents, 2, ' ', ',');
        default: return fmt(cents, 2);
      }
    });
  }

  /* ---------- Produkt-Varianten ---------- */
  function initProduct() {
    document.querySelectorAll('[data-product]').forEach(function (root) {
      var json = root.querySelector('[data-variants-json]');
      var idInput = root.querySelector('[data-variant-id]');
      if (!json || !idInput) return;
      var variants = JSON.parse(json.textContent);
      var moneyFormat = root.getAttribute('data-money-format');
      var fieldsets = root.querySelectorAll('[data-option]');
      var priceEl = root.querySelector('[data-price]');
      var compareEl = root.querySelector('[data-compare-price]');
      var priceWrap = priceEl ? priceEl.closest('.price') : null;
      var addBtn = root.querySelector('[data-add-button]');
      var addLabel = root.querySelector('[data-add-label]');

      var current = variants.find(function (v) { return String(v.id) === String(idInput.value); }) || variants[0];
      if (current) {
        fieldsets.forEach(function (fs, idx) {
          fs.querySelectorAll('input').forEach(function (inp) { inp.checked = inp.value === current.options[idx]; });
        });
      }

      function selected() {
        return Array.prototype.map.call(fieldsets, function (fs) {
          var c = fs.querySelector('input:checked');
          return c ? c.value : null;
        });
      }

      function markAvailability(sel) {
        fieldsets.forEach(function (fs, idx) {
          fs.querySelectorAll('input').forEach(function (inp) {
            var test = sel.slice(); test[idx] = inp.value;
            var ok = variants.some(function (v) { return v.available && v.options.every(function (o, i) { return o === test[i]; }); });
            var label = fs.querySelector('label[for="' + inp.id + '"]');
            if (label) label.classList.toggle('is-unavailable', !ok);
          });
        });
      }

      function update() {
        var sel = selected();
        var variant = variants.find(function (v) { return v.options.every(function (o, i) { return o === sel[i]; }); });
        fieldsets.forEach(function (fs, idx) {
          var out = fs.querySelector('[data-option-value]');
          if (out) out.textContent = sel[idx] || '';
        });
        markAvailability(sel);
        if (!variant) {
          if (addBtn) addBtn.disabled = true;
          if (addLabel) addLabel.textContent = 'Nicht verfügbar';
          return;
        }
        idInput.value = variant.id;
        if (priceEl) priceEl.textContent = formatMoney(variant.price, moneyFormat);
        if (compareEl) {
          var onSale = variant.compare_at_price && variant.compare_at_price > variant.price;
          compareEl.hidden = !onSale;
          compareEl.textContent = onSale ? formatMoney(variant.compare_at_price, moneyFormat) : '';
          if (priceWrap) priceWrap.classList.toggle('price--sale', !!onSale);
        }
        if (addBtn) addBtn.disabled = !variant.available;
        if (addLabel) addLabel.textContent = variant.available ? 'In den Warenkorb' : 'Ausverkauft';
        if (variant.featured_media) {
          var m = root.querySelector('[data-media-id="' + variant.featured_media.id + '"]');
          var gallery = m ? m.parentElement : null;
          if (m && gallery && gallery.firstElementChild !== m) {
            gallery.querySelectorAll('.is-first').forEach(function (el) { el.classList.remove('is-first'); });
            m.classList.add('is-first');
            gallery.insertBefore(m, gallery.firstElementChild);
          }
        }
        var url = new URL(window.location.href);
        url.searchParams.set('variant', variant.id);
        window.history.replaceState({}, '', url.toString());
      }

      fieldsets.forEach(function (fs) { fs.addEventListener('change', update); });
      if (fieldsets.length) markAvailability(selected());

      var form = root.querySelector('form[action*="/cart/add"]');
      var msg = root.querySelector('[data-form-message]');
      function say(text, isError) {
        if (!msg) return;
        msg.hidden = !text;
        msg.textContent = text || '';
        msg.classList.toggle('form-message--error', !!isError);
      }
      if (form && window.fetch) {
        form.addEventListener('submit', function (e) {
          e.preventDefault();
          if (addBtn) addBtn.disabled = true;
          var prev = addLabel ? addLabel.textContent : '';
          if (addLabel) addLabel.textContent = 'Kommt in den Warenkorb …';
          say('');
          var root_url = (window.Shopify && Shopify.routes && Shopify.routes.root) || '/';
          fetch(root_url + 'cart/add.js', { method: 'POST', headers: { 'Accept': 'application/json' }, body: new FormData(form) })
            .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, data: d }; }); })
            .then(function (res) {
              if (!res.ok) {
                var err = new Error(res.data.description || res.data.message || '');
                err.userFacing = !!res.data.description;
                throw err;
              }
              if (addLabel) addLabel.textContent = 'Liegt im Warenkorb';
              say('Liegt im Warenkorb. Weiter stöbern oder direkt zur Kasse.');
              return fetch(root_url + 'cart.js').then(function (r) { return r.json(); });
            })
            .then(function (cart) {
              document.querySelectorAll('[data-cart-count]').forEach(function (el) {
                el.textContent = cart.item_count;
                el.classList.toggle('is-empty', cart.item_count === 0);
              });
              setTimeout(function () {
                if (addLabel) addLabel.textContent = prev;
                if (addBtn) addBtn.disabled = false;
              }, 2000);
            })
            .catch(function (err) {
              if (addLabel) addLabel.textContent = prev;
              if (addBtn) addBtn.disabled = false;
              say(err.userFacing ? err.message : 'Da ist was schiefgelaufen. Probier’s bitte gleich noch mal.', true);
            });
        });
      }
    });
  }

  /* ---------- Produktempfehlungen ---------- */
  function initRecommendations() {
    var el = document.querySelector('[data-recommendations]');
    if (!el || el.children.length || !window.fetch) return;
    fetch(el.getAttribute('data-url'))
      .then(function (r) { return r.text(); })
      .then(function (html) {
        var tmp = document.createElement('div');
        tmp.innerHTML = html;
        var inner = tmp.querySelector('[data-recommendations]');
        if (inner && inner.innerHTML.trim()) el.innerHTML = inner.innerHTML;
      })
      .catch(function () {});
  }

  /* ---------- Login: Passwort vergessen ---------- */
  function initRecover() {
    var link = document.querySelector('[data-recover-toggle]');
    var box = document.getElementById('recover');
    if (!box) return;
    if (link) link.addEventListener('click', function (e) {
      e.preventDefault();
      box.classList.toggle('is-open');
      if (box.classList.contains('is-open')) box.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth' });
    });
    if (box.querySelector('.form-success, .form-error')) box.classList.add('is-open');
  }

  /* ---------- Adressen: Land vorauswählen, Löschen bestätigen ---------- */
  function initAddresses() {
    document.querySelectorAll('select[data-default]').forEach(function (s) {
      var d = s.getAttribute('data-default');
      if (d) s.value = d;
    });
    document.querySelectorAll('form[data-confirm]').forEach(function (f) {
      f.addEventListener('submit', function (e) {
        if (!window.confirm(f.getAttribute('data-confirm'))) e.preventDefault();
      });
    });
  }

  function init() {
    initMenu(); initSearch(); initAnnouncement(); initQty(); initSort();
    initProduct(); initRecommendations(); initRecover(); initAddresses(); initCartAutoUpdate();
    // Theme-Editor: Live-Vorschau beim Bearbeiten einer Sektion neu verdrahten
    document.addEventListener('shopify:section:load', function () {
      initAnnouncement(); initProduct(); initRecommendations();
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
